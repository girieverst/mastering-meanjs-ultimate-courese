export interface CartItem {
  id: number;
  price: number;
  name: string;
  imgUrl: string;
  quantity: number;
  itemTotal: number;
}
